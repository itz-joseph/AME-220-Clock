
function updateClocks() {
    const options = { hour: '2-digit', minute: '2-digit', second: '2-digit' };

    document.getElementById('eastern').innerHTML = 
        "Eastern: " + new Date().toLocaleTimeString('en-US', { ...options, timeZone: 'America/New_York' });

    document.getElementById('central').innerHTML = 
        "Central: " + new Date().toLocaleTimeString('en-US', { ...options, timeZone: 'America/Chicago' });

    document.getElementById('mountain').innerHTML = 
        "Mountain: " + new Date().toLocaleTimeString('en-US', { ...options, timeZone: 'America/Denver' });

    document.getElementById('pacific').innerHTML = 
        "Pacific: " + new Date().toLocaleTimeString('en-US', { ...options, timeZone: 'America/Los_Angeles' });
}

setInterval(updateClocks, 1000);
updateClocks();
