function updateClocks() {
  const now = new Date();

  const options = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true };

  const timeZones = {
    "clock-et": "America/New_York",
    "clock-ct": "America/Chicago",
    "clock-mt": "America/Denver",
    "clock-pt": "America/Los_Angeles",
  };

  for (const [id, zone] of Object.entries(timeZones)) {
    const time = now.toLocaleTimeString("en-US", { ...options, timeZone: zone });
    document.getElementById(id).textContent = time;
  }
}

setInterval(updateClocks, 1000);
updateClocks(); // Run immediately on load

// Accordion toggle
document.querySelector('.accordion-toggle').addEventListener('click', function () {
  const content = document.querySelector('.accordion-content');
  const isOpen = content.style.maxHeight && content.style.maxHeight !== "0px";
  content.style.maxHeight = isOpen ? "0px" : content.scrollHeight + "px";
});
